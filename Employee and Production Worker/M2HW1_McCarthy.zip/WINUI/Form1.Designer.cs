﻿
namespace WINUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeNameLabel = new System.Windows.Forms.Label();
            this.employeeNumberLabel = new System.Windows.Forms.Label();
            this.shiftNumberLabel = new System.Windows.Forms.Label();
            this.hourlyPayLabel = new System.Windows.Forms.Label();
            this.employeeNameTextBox = new System.Windows.Forms.TextBox();
            this.employeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.shiftNumberTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.displayEmployeeNameLabel = new System.Windows.Forms.Label();
            this.displayEmployeeNumberLabel = new System.Windows.Forms.Label();
            this.displayShiftNumber = new System.Windows.Forms.Label();
            this.displayHourlyPayLabel = new System.Windows.Forms.Label();
            this.createObjectButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // employeeNameLabel
            // 
            this.employeeNameLabel.AutoSize = true;
            this.employeeNameLabel.Location = new System.Drawing.Point(13, 29);
            this.employeeNameLabel.Name = "employeeNameLabel";
            this.employeeNameLabel.Size = new System.Drawing.Size(115, 17);
            this.employeeNameLabel.TabIndex = 0;
            this.employeeNameLabel.Text = "Employee Name:";
            // 
            // employeeNumberLabel
            // 
            this.employeeNumberLabel.AutoSize = true;
            this.employeeNumberLabel.Location = new System.Drawing.Point(13, 58);
            this.employeeNumberLabel.Name = "employeeNumberLabel";
            this.employeeNumberLabel.Size = new System.Drawing.Size(128, 17);
            this.employeeNumberLabel.TabIndex = 1;
            this.employeeNumberLabel.Text = "Employee Number:";
            // 
            // shiftNumberLabel
            // 
            this.shiftNumberLabel.AutoSize = true;
            this.shiftNumberLabel.Location = new System.Drawing.Point(13, 92);
            this.shiftNumberLabel.Name = "shiftNumberLabel";
            this.shiftNumberLabel.Size = new System.Drawing.Size(94, 17);
            this.shiftNumberLabel.TabIndex = 2;
            this.shiftNumberLabel.Text = "Shift Number:";
            // 
            // hourlyPayLabel
            // 
            this.hourlyPayLabel.AutoSize = true;
            this.hourlyPayLabel.Location = new System.Drawing.Point(16, 125);
            this.hourlyPayLabel.Name = "hourlyPayLabel";
            this.hourlyPayLabel.Size = new System.Drawing.Size(81, 17);
            this.hourlyPayLabel.TabIndex = 3;
            this.hourlyPayLabel.Text = "Hourly Pay:";
            // 
            // employeeNameTextBox
            // 
            this.employeeNameTextBox.Location = new System.Drawing.Point(135, 29);
            this.employeeNameTextBox.Name = "employeeNameTextBox";
            this.employeeNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.employeeNameTextBox.TabIndex = 4;
            // 
            // employeeNumberTextBox
            // 
            this.employeeNumberTextBox.Location = new System.Drawing.Point(148, 58);
            this.employeeNumberTextBox.Name = "employeeNumberTextBox";
            this.employeeNumberTextBox.Size = new System.Drawing.Size(100, 22);
            this.employeeNumberTextBox.TabIndex = 5;
            // 
            // shiftNumberTextBox
            // 
            this.shiftNumberTextBox.Location = new System.Drawing.Point(114, 92);
            this.shiftNumberTextBox.Name = "shiftNumberTextBox";
            this.shiftNumberTextBox.Size = new System.Drawing.Size(100, 22);
            this.shiftNumberTextBox.TabIndex = 6;
            // 
            // hourlyPayTextBox
            // 
            this.hourlyPayTextBox.Location = new System.Drawing.Point(104, 125);
            this.hourlyPayTextBox.Name = "hourlyPayTextBox";
            this.hourlyPayTextBox.Size = new System.Drawing.Size(100, 22);
            this.hourlyPayTextBox.TabIndex = 7;
            // 
            // displayEmployeeNameLabel
            // 
            this.displayEmployeeNameLabel.AutoSize = true;
            this.displayEmployeeNameLabel.Location = new System.Drawing.Point(16, 170);
            this.displayEmployeeNameLabel.Name = "displayEmployeeNameLabel";
            this.displayEmployeeNameLabel.Size = new System.Drawing.Size(115, 17);
            this.displayEmployeeNameLabel.TabIndex = 8;
            this.displayEmployeeNameLabel.Text = "Employee Name:";
            // 
            // displayEmployeeNumberLabel
            // 
            this.displayEmployeeNumberLabel.AutoSize = true;
            this.displayEmployeeNumberLabel.Location = new System.Drawing.Point(16, 197);
            this.displayEmployeeNumberLabel.Name = "displayEmployeeNumberLabel";
            this.displayEmployeeNumberLabel.Size = new System.Drawing.Size(128, 17);
            this.displayEmployeeNumberLabel.TabIndex = 9;
            this.displayEmployeeNumberLabel.Text = "Employee Number:";
            // 
            // displayShiftNumber
            // 
            this.displayShiftNumber.AutoSize = true;
            this.displayShiftNumber.Location = new System.Drawing.Point(16, 224);
            this.displayShiftNumber.Name = "displayShiftNumber";
            this.displayShiftNumber.Size = new System.Drawing.Size(94, 17);
            this.displayShiftNumber.TabIndex = 10;
            this.displayShiftNumber.Text = "Shift Number:";
            // 
            // displayHourlyPayLabel
            // 
            this.displayHourlyPayLabel.AutoSize = true;
            this.displayHourlyPayLabel.Location = new System.Drawing.Point(19, 245);
            this.displayHourlyPayLabel.Name = "displayHourlyPayLabel";
            this.displayHourlyPayLabel.Size = new System.Drawing.Size(81, 17);
            this.displayHourlyPayLabel.TabIndex = 11;
            this.displayHourlyPayLabel.Text = "Hourly Pay:";
            // 
            // createObjectButton
            // 
            this.createObjectButton.Location = new System.Drawing.Point(40, 318);
            this.createObjectButton.Name = "createObjectButton";
            this.createObjectButton.Size = new System.Drawing.Size(163, 41);
            this.createObjectButton.TabIndex = 12;
            this.createObjectButton.Text = "Create Object";
            this.createObjectButton.UseVisualStyleBackColor = true;
            this.createObjectButton.Click += new System.EventHandler(this.createObjectButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.createObjectButton);
            this.Controls.Add(this.displayHourlyPayLabel);
            this.Controls.Add(this.displayShiftNumber);
            this.Controls.Add(this.displayEmployeeNumberLabel);
            this.Controls.Add(this.displayEmployeeNameLabel);
            this.Controls.Add(this.hourlyPayTextBox);
            this.Controls.Add(this.shiftNumberTextBox);
            this.Controls.Add(this.employeeNumberTextBox);
            this.Controls.Add(this.employeeNameTextBox);
            this.Controls.Add(this.hourlyPayLabel);
            this.Controls.Add(this.shiftNumberLabel);
            this.Controls.Add(this.employeeNumberLabel);
            this.Controls.Add(this.employeeNameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label employeeNameLabel;
        private System.Windows.Forms.Label employeeNumberLabel;
        private System.Windows.Forms.Label shiftNumberLabel;
        private System.Windows.Forms.Label hourlyPayLabel;
        private System.Windows.Forms.TextBox employeeNameTextBox;
        private System.Windows.Forms.TextBox employeeNumberTextBox;
        private System.Windows.Forms.TextBox shiftNumberTextBox;
        private System.Windows.Forms.TextBox hourlyPayTextBox;
        private System.Windows.Forms.Label displayEmployeeNameLabel;
        private System.Windows.Forms.Label displayEmployeeNumberLabel;
        private System.Windows.Forms.Label displayShiftNumber;
        private System.Windows.Forms.Label displayHourlyPayLabel;
        private System.Windows.Forms.Button createObjectButton;
    }
}

