﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 9/23/23
* CSC 253
* David McCarthy
* This program uses inheirtance to make a production worker class from an employee class and displays the objects values on the form
*/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void createObjectButton_Click(object sender, EventArgs e)
        {
            ProductionWorker productionWorker = new ProductionWorker();
            GetProductionWorker(productionWorker);
            displayEmployeeNameLabel.Text = "Employee Name: " + productionWorker.EmployeeName;
            displayEmployeeNumberLabel.Text = "Employee Number: " + productionWorker.EmployeeNumber.ToString();
            displayShiftNumber.Text = "Shift Number: " + productionWorker.ShiftNumber.ToString();
            displayHourlyPayLabel.Text = "Hourly Pay: " + productionWorker.HourlyPay.ToString();

        }
        private void GetProductionWorker(ProductionWorker productionWorker)
        {
            int employeeNumber;
            int shiftNumber;
            double hourlyPay;
            productionWorker.EmployeeName = employeeNameTextBox.Text;
            if (int.TryParse(employeeNumberTextBox.Text, out employeeNumber))
            {
                productionWorker.EmployeeNumber = employeeNumber;

                if (int.TryParse(shiftNumberTextBox.Text, out shiftNumber))
                    {
                        productionWorker.ShiftNumber = shiftNumber;
                        if (double.TryParse(hourlyPayTextBox.Text, out hourlyPay))
                        {
                            productionWorker.HourlyPay = hourlyPay;
                        }
                        else
                        {
                        MessageBox.Show("Invalid HourlyPay");                        
                        }
                    }
                else
                {
                    MessageBox.Show("Invalid Shift Number");
                }
            }
            else
            {
                MessageBox.Show("Invalid Employee Number");
            }
        }
    }
}

