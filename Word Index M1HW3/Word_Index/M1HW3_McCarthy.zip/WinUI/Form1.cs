﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WinUI
{
    /**
    * 9/18/2023
    * CSC 253
    * David McCarthy
    * This program takes a file and gets the indexs for the words in the file. (Check debug bin for WordIndex.Txt to see indexes)
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void indexFileButton_Click(object sender, EventArgs e)
        {
            List<int> aIndex = new List<int>() { };
            List<int> anIndex = new List<int>();
            List<int> asIndex = new List<int>();
            List<int> beginningIndex = new List<int>();
            List<int> butIndex = new List<int>();
            List<int> celebrationIndex = new List<int>();
            List<int> changeIndex = new List<int>();
            List<int> endIndex = new List<int>();
            List<int> freedomIndex = new List<int>();
            List<int> notIndex = new List<int>();
            List<int> observeIndex = new List<int>();
            List<int> ofIndex = new List<int>();
            List<int> partyIndex = new List<int>();
            List<int> renewalIndex = new List<int>();
            List<int> signifyingIndex = new List<int>();
            List<int> symbolizingIndex = new List<int>();
            List<int> todayIndex = new List<int>();
            List<int> victoryIndex = new List<int>();
            List<int> weIndex = new List<int>();
            List<int> wellIndex = new List<int>();
            Dictionary<string, List<int>> wordIndexes = new Dictionary<string, List<int>>()
            {
                {"a",aIndex},
                {"an",anIndex},
                {"as", asIndex},
                {"beginning", beginningIndex},
                {"but", butIndex},
                {"celebration", celebrationIndex},
                {"change", changeIndex},
                {"end", endIndex},
                {"freedom", freedomIndex},
                {"not", notIndex},
                {"observe", observeIndex},
                {"of", ofIndex},
                {"party", partyIndex},
                {"renewal", renewalIndex},
                {"signifying", signifyingIndex},
                {"symbolizing", symbolizingIndex},
                {"today", todayIndex},
                {"victory", victoryIndex},
                {"we", weIndex},
                {"well", wellIndex }
            };
            StreamReader Outputfile;
            string line1;
            string line2;
            string line3;
            string line4;
            string line5;
            string line6;
            string[] firstLineWords;
            string[] secondLineWords;
            string[] thirdLineWords;
            string[] fourthLineWords;
            string[] fifthLineWords;
            string[] sixthLineWords;
            Outputfile = File.OpenText("Kennedy.txt");
            line1 = Outputfile.ReadLine();
            line2 = Outputfile.ReadLine();
            line3 = Outputfile.ReadLine();
            line4 = Outputfile.ReadLine();
            line5 = Outputfile.ReadLine();
            line6 = Outputfile.ReadLine();
            Outputfile.Close();
            firstLineWords = line1.Split(' ');
            secondLineWords = line2.Split(' ');
            thirdLineWords = line3.Split(' ');
            fourthLineWords = line4.Split(' ');
            fifthLineWords = line5.Split(' ');
            sixthLineWords = line6.Split(' ');
            foreach (string word in firstLineWords)
            {
                if (word == "a")
                {
                    aIndex.Add(1);
                }
                else if (word == "an")
                {
                    anIndex.Add(1);
                }
                else if (word == "as")
                {
                    asIndex.Add(1);
                }
                else if (word == "beginning")
                {
                    beginningIndex.Add(1);
                }
                else if (word == "but")
                {
                    butIndex.Add(1);
                }
                else if (word == "celebration")
                {
                    celebrationIndex.Add(1);
                }
                else if (word == "change")
                {
                    changeIndex.Add(1);
                }
                else if (word == "end")
                {
                    endIndex.Add(1);
                }
                else if (word == "freedom")
                {
                    freedomIndex.Add(1);
                }
                else if (word == "not")
                {
                    notIndex.Add(1);
                }
                else if (word == "observe")
                {
                    observeIndex.Add(1);
                }
                else if (word == "of")
                {
                    ofIndex.Add(1);
                }
                else if (word == "party")
                {
                    partyIndex.Add(1);
                }
                else if (word == "renewal")
                {
                    renewalIndex.Add(1);
                }
                else if (word == "signifying")
                {
                    signifyingIndex.Add(1);
                }
                else if (word == "symbolizing")
                {
                    symbolizingIndex.Add(1);
                }
                else if (word == "today")
                {
                    todayIndex.Add(1);
                }
                else if (word == "victory")
                {
                    victoryIndex.Add(1);
                }
                else if (word == "We")
                {
                    weIndex.Add(1);
                }
                else if (word == "well")
                {
                    wellIndex.Add(1);
                }
            }
            foreach (string word2 in secondLineWords)
            {
                if (word2 == "a")
                {
                    aIndex.Add(2);
                }
                else if (word2 == "an")
                {
                    anIndex.Add(2);
                }
                else if (word2 == "as")
                {
                    asIndex.Add(2);
                }
                else if (word2 == "beginning")
                {
                    beginningIndex.Add(2);
                }
                else if (word2 == "but")
                {
                    butIndex.Add(2);
                }
                else if (word2 == "celebration")
                {
                    celebrationIndex.Add(2);
                }
                else if (word2 == "change")
                {
                    changeIndex.Add(2);
                }
                else if (word2 == "end")
                {
                    endIndex.Add(2);
                }
                else if (word2 == "freedom")
                {
                    freedomIndex.Add(2);
                }
                else if (word2 == "not")
                {
                    notIndex.Add(2);
                }
                else if (word2 == "observe")
                {
                    observeIndex.Add(2);
                }
                else if (word2 == "of")
                {
                    ofIndex.Add(2);
                }
                else if (word2 == "party")
                {
                    partyIndex.Add(2);
                }
                else if (word2 == "renewal")
                {
                    renewalIndex.Add(2);
                }
                else if (word2 == "signifying")
                {
                    signifyingIndex.Add(2);
                }
                else if (word2 == "symbolizing")
                {
                    symbolizingIndex.Add(2);
                }
                else if (word2 == "today")
                {
                    todayIndex.Add(2);
                }
                else if (word2 == "victory")
                {
                    victoryIndex.Add(2);
                }
                else if (word2 == "We")
                {
                    weIndex.Add(2);
                }
                else if (word2 == "well")
                {
                    wellIndex.Add(2);
                }
            }
            foreach (string word3 in thirdLineWords)
            {
                if (word3 == "a")
                {
                    aIndex.Add(3);
                }
                else if (word3 == "an")
                {
                    anIndex.Add(3);
                }
                else if (word3 == "as")
                {
                    asIndex.Add(3);
                }
                else if (word3 == "beginning")
                {
                    beginningIndex.Add(3);
                }
                else if (word3 == "but")
                {
                    butIndex.Add(3);
                }
                else if (word3 == "celebration")
                {
                    celebrationIndex.Add(3);
                }
                else if (word3 == "change")
                {
                    changeIndex.Add(3);
                }
                else if (word3 == "end")
                {
                    endIndex.Add(3);
                }
                else if (word3 == "freedom")
                {
                    freedomIndex.Add(3);
                }
                else if (word3 == "not")
                {
                    notIndex.Add(3);
                }
                else if (word3 == "observe")
                {
                    observeIndex.Add(3);
                }
                else if (word3 == "of")
                {
                    ofIndex.Add(3);
                }
                else if (word3 == "party")
                {
                    partyIndex.Add(3);
                }
                else if (word3 == "renewal")
                {
                    renewalIndex.Add(3);
                }
                else if (word3 == "signifying")
                {
                    signifyingIndex.Add(3);
                }
                else if (word3 == "symbolizing")
                {
                    symbolizingIndex.Add(3);
                }
                else if (word3 == "today")
                {
                    todayIndex.Add(3);
                }
                else if (word3 == "victory")
                {
                    victoryIndex.Add(3);
                }
                else if (word3 == "We")
                {
                    weIndex.Add(3);
                }
                else if (word3 == "well")
                {
                    wellIndex.Add(3);
                }
            }
            foreach (string word4 in fourthLineWords)
            {
                if (word4 == "a")
                {
                    aIndex.Add(4);
                }
                else if (word4 == "an")
                {
                    anIndex.Add(4);
                }
                else if (word4 == "as")
                {
                    asIndex.Add(4);
                }
                else if (word4 == "beginning")
                {
                    beginningIndex.Add(4);
                }
                else if (word4 == "but")
                {
                    butIndex.Add(4);
                }
                else if (word4 == "celebration")
                {
                    celebrationIndex.Add(4);
                }
                else if (word4 == "change")
                {
                    changeIndex.Add(4);
                }
                else if (word4 == "end")
                {
                    endIndex.Add(4);
                }
                else if (word4 == "freedom")
                {
                    freedomIndex.Add(4);
                }
                else if (word4 == "not")
                {
                    notIndex.Add(4);
                }
                else if (word4 == "observe")
                {
                    observeIndex.Add(4);
                }
                else if (word4 == "of")
                {
                    ofIndex.Add(4);
                }
                else if (word4 == "party")
                {
                    partyIndex.Add(4);
                }
                else if (word4 == "renewal")
                {
                    renewalIndex.Add(4);
                }
                else if (word4 == "signifying")
                {
                    signifyingIndex.Add(4);
                }
                else if (word4 == "symbolizing")
                {
                    symbolizingIndex.Add(4);
                }
                else if (word4 == "today")
                {
                    todayIndex.Add(4);
                }
                else if (word4 == "victory")
                {
                    victoryIndex.Add(4);
                }
                else if (word4 == "We")
                {
                    weIndex.Add(4);
                }
                else if (word4 == "well")
                {
                    wellIndex.Add(4);
                }
            }
                foreach (string word5 in fifthLineWords)
                {
                    if (word5 == "a")
                    {
                        aIndex.Add(5);
                    }
                    else if (word5 == "an")
                    {
                        anIndex.Add(5);
                    }
                    else if (word5 == "as")
                    {
                        asIndex.Add(5);
                    }
                    else if (word5 == "beginning")
                    {
                        beginningIndex.Add(5);
                    }
                    else if (word5 == "but")
                    {
                        butIndex.Add(5);
                    }
                    else if (word5 == "celebration")
                    {
                        celebrationIndex.Add(5);
                    }
                    else if (word5 == "change")
                    {
                        changeIndex.Add(5);
                    }
                    else if (word5 == "end")
                    {
                        endIndex.Add(5);
                    }
                    else if (word5 == "freedom")
                    {
                        freedomIndex.Add(5);
                    }
                    else if (word5 == "not")
                    {
                        notIndex.Add(5);
                    }
                    else if (word5 == "observe")
                    {
                        observeIndex.Add(5);
                    }
                    else if (word5 == "of")
                    {
                        ofIndex.Add(5);
                    }
                    else if (word5 == "party")
                    {
                        partyIndex.Add(5);
                    }
                    else if (word5 == "renewal")
                    {
                        renewalIndex.Add(5);
                    }
                    else if (word5 == "signifying")
                    {
                        signifyingIndex.Add(5);
                    }
                    else if (word5 == "symbolizing")
                    {
                        symbolizingIndex.Add(5);
                    }
                    else if (word5 == "today")
                    {
                        todayIndex.Add(5);
                    }
                    else if (word5 == "victory")
                    {
                        victoryIndex.Add(5);
                    }
                    else if (word5 == "We")
                    {
                        weIndex.Add(5);
                    }
                    else if (word5 == "well")
                    {
                        wellIndex.Add(5);
                    }
                }
                foreach (string word6 in sixthLineWords)
                {
                    if (word6 == "a")
                    {
                        aIndex.Add(6);
                    }
                    else if (word6 == "an")
                    {
                    anIndex.Add(6);
                    }
                    else if (word6 == "as")
                    {
                        asIndex.Add(6);
                    }
                    else if (word6 == "beginning")
                    {
                        beginningIndex.Add(6);
                    }
                    else if (word6 == "but")
                    {
                        butIndex.Add(6);
                    }
                    else if (word6 == "celebration")
                    {
                        celebrationIndex.Add(6);
                    }
                    else if (word6 == "change")
                    {
                        changeIndex.Add(6);
                    }
                    else if (word6 == "end")
                    {
                        endIndex.Add(6);
                    }
                    else if (word6 == "freedom")
                    {
                        freedomIndex.Add(6);
                    }
                    else if (word6 == "not")
                    {
                        notIndex.Add(6);
                    }
                    else if (word6 == "observe")
                    {
                        observeIndex.Add(6);
                    }
                    else if (word6 == "of")
                    {
                        ofIndex.Add(6);
                    }
                    else if (word6 == "party")
                    {
                        partyIndex.Add(6);
                    }
                    else if (word6 == "renewal")
                    {
                        renewalIndex.Add(6);
                    }
                    else if (word6 == "signifying")
                    {
                        signifyingIndex.Add(6);
                    }
                    else if (word6 == "symbolizing")
                    {
                        symbolizingIndex.Add(6);
                    }
                    else if (word6 == "today")
                    {
                        todayIndex.Add(6);
                    }
                    else if (word6 == "victory")
                    {
                        victoryIndex.Add(6);
                    }
                    else if (word6 == "We")
                    {
                        weIndex.Add(6);
                    }
                    else if (word6 == "well")
                    {
                        wellIndex.Add(6);
                    }
                }
            StreamWriter inputFile;
            inputFile = File.CreateText("WordIndex.txt");
            inputFile.WriteLine("a: " + aIndex[0].ToString() + " " + aIndex[1].ToString() + " " + aIndex[2].ToString());
            inputFile.WriteLine("an: " + anIndex[0].ToString());
            inputFile.WriteLine("as: " + asIndex[0].ToString() + " " + asIndex[1].ToString() + " " + asIndex[2].ToString());
            inputFile.WriteLine("beginning: " + beginningIndex[0].ToString());
            inputFile.WriteLine("but: " + butIndex[0].ToString());
            inputFile.WriteLine("celebration: " + celebrationIndex[0].ToString());
            inputFile.WriteLine("change: " + changeIndex[0].ToString());
            inputFile.WriteLine("end: " + endIndex[0].ToString());
            inputFile.WriteLine("freedom: " + freedomIndex[0].ToString());
            inputFile.WriteLine("not: " + notIndex[0].ToString());
            inputFile.WriteLine("observe: " + observeIndex[0].ToString());
            inputFile.WriteLine("of: " + ofIndex[0].ToString() + " " + ofIndex[1].ToString());
            inputFile.WriteLine("party: " + partyIndex[0].ToString());
            inputFile.WriteLine("renewal: " + renewalIndex[0].ToString());
            inputFile.WriteLine("signifying: " + signifyingIndex[0].ToString());
            inputFile.WriteLine("symbolizing: " + symbolizingIndex[0].ToString());
            inputFile.WriteLine("today: " + todayIndex[0].ToString());
            inputFile.WriteLine("victory: " + victoryIndex[0].ToString());
            inputFile.WriteLine("We: " + weIndex[0].ToString());
            inputFile.WriteLine("well: " + wellIndex[0].ToString() + " " + wellIndex[1].ToString());
            inputFile.Close();
        }
    }
}
