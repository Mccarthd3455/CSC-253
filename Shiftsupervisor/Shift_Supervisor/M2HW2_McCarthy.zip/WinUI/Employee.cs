﻿using System;

public class Employee
{
	public Employee()
	{
            EmployeeName = "";
            EmployeeNumber = 0;
    }
    public int EmployeeNumber { get; set; }
    public string EmployeeName { get; set; }
}
