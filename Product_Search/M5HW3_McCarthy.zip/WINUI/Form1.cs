﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 11/27/2023
* CSC 253
* David McCarthy
* This program uses a datagrid view to show the Products table then uses an dbml file to allow sql to linq to access the Products table
* and search for product number or description using the .Contains method to check all of the enteries in the table
**/
namespace WINUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ProductDataContext db = new ProductDataContext();
            var results = from product in db.Products
                          select product;
            productDataGridView.DataSource = results;
        }

        private void searchProductNumberbutton_Click(object sender, EventArgs e)
        {
            ProductDataContext db = new ProductDataContext();
            string ProductNumber = productNumberTextBox.Text;
            var results = from product in db.Products
                          where product.Product_Number.Contains(ProductNumber)
                          select product;
            productDataGridView.DataSource = results;
        }

        private void searchDescriptionButton_Click(object sender, EventArgs e)
        {
            ProductDataContext db = new ProductDataContext();
            string Description = descriptionTextBox.Text;
            var results = from product in db.Products
                          where product.Description.Contains(Description)
                          select product;
            productDataGridView.DataSource = results;
        }

        private void resetTableButton_Click(object sender, EventArgs e)
        {
            ProductDataContext db = new ProductDataContext();
            var results = from product in db.Products
                          select product;
            productDataGridView.DataSource = results;
        }
    }
}
